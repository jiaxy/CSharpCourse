using System;
using System.IO;
using System.Threading;


class Test
{
	static void Main()
	{
        ThreadPool.SetMaxThreads(2, 2); // ���ڵ���CPU����, 2�������̡߳�2���첽I/O�߳�
        int workerThreads, completionThreads;
        ThreadPool.GetMaxThreads(out workerThreads, out completionThreads);
        Console.WriteLine($"workerThreads��{workerThreads},completionThreads��{completionThreads}");

        for (int i = 1; i < 100; i++){
            ThreadPool.QueueUserWorkItem(new WaitCallback(Fun), i);
        }
        Console.ReadKey();
	}

	static void Fun(object obj )
	{
        int n = (int)obj;
        Console.WriteLine(
              $"��ǰֵΪ��{n}," +
              $"�߳�ID={Thread.CurrentThread.ManagedThreadId}");
        Thread.Sleep(200);
	}



}
